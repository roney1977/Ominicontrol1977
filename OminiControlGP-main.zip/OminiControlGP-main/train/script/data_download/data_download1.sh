huggingface-cli download --repo-type dataset Yuanshi/Subjects200K
